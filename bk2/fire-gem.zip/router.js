/* ================================================================= *
 * RRU - State Router, Deployment Dispatcher & NEB Store (router.js) *
 * ================================================================= *
 * Updated: Tracker State Snapshot & Persistence Layer               *
 * ================================================================= */

(function () {
    'use strict';

    // --- Global Network Registry ---
    window.atoms = window.atoms || [];
    let selectedNodeForInspection = null;

    // --- Helper to read live UI slider/input values ---
    function getUIHue() {
        const el = document.getElementById('node-hue') || 
                   document.getElementById('hue-slider') || 
                   document.getElementById('node-hue-slider');
        return el ? Number(el.value) || 185 : 185;
    }

    function getUIInnerHue() {
        const el = document.getElementById('node-inner-hue') || 
                   document.getElementById('inner-hue-slider');
        return el ? Number(el.value) || 230 : 230;
    }

    function getUIScale() {
        const el = document.getElementById('node-scale') || 
                   document.getElementById('scale-slider') || 
                   document.getElementById('node-scale-slider');
        return el ? Number(el.value) || 1.0 : 1.0;
    }

    // --- Universal Node Factory & Property Enforcer ---
    window.createRRUNode = function(type, position, id, hue, scale, cardData = {}, innerHue) {
        let newNode;
        const safeHue = (hue !== undefined && hue !== null) ? Number(hue) : getUIHue();
        const safeInnerHue = (innerHue !== undefined && innerHue !== null) ? Number(innerHue) : ((safeHue + 45) % 360);
        const safeScale = (scale !== undefined && scale !== null) ? Number(scale) : getUIScale();
        const safeId = id || ++window.RRURouter.nextNodeId;

        if (type === 'sign' && typeof SignNode === 'function') {
            newNode = new SignNode(position, safeId, safeHue, safeScale, cardData);
        } else if (type === 'firegem' && typeof FireGemNode === 'function') {
            newNode = new FireGemNode(position, safeId, safeScale, cardData);
        } else if (type === 'stargate' || type === 'atom' || typeof Atom === 'function') {
            newNode = new Atom(position, safeId, safeHue, safeScale, type, cardData);
        } else {
            newNode = new Atom(position, safeId, safeHue, safeScale, 'stargate', cardData);
        }

        if (newNode) {
            newNode.cardType = type;
            newNode.hue = safeHue;
            newNode.innerHue = safeInnerHue;
            newNode.scaleMultiplier = safeScale;
            newNode.cardData = cardData;

            if (typeof newNode.setScale === 'function') {
                newNode.setScale(safeScale);
            } else {
                const targetObject = newNode.group || newNode.mesh || newNode;
                if (targetObject && targetObject.scale && typeof targetObject.scale.set === 'function') {
                    targetObject.scale.set(safeScale, safeScale, safeScale);
                }
            }

            if (typeof newNode.setHue === 'function') {
                newNode.setHue(safeHue);
            } else if (typeof newNode.updateHue === 'function') {
                newNode.updateHue(safeHue);
            } else if (typeof newNode.updateColor === 'function') {
                newNode.updateColor(safeHue);
            }

            if (typeof newNode.setInnerHue === 'function') {
                newNode.setInnerHue(safeInnerHue);
            } else if (typeof newNode.updateInnerHue === 'function') {
                newNode.updateInnerHue(safeInnerHue);
            }
        }

        return newNode;
    };

    // --- Storage & Cookie Helpers ---
    window.setCookie = function(name, value, days = 30) {
        try {
            const d = new Date();
            d.setTime(d.getTime() + (days * 24 * 60 * 60 * 1000));
            const expires = "expires=" + d.toUTCString();
            const jsonString = JSON.stringify(value);
            document.cookie = `${name}=${encodeURIComponent(jsonString)}; ${expires}; path=/; SameSite=Lax`;
            console.log(`[RRUNebStore] Cookie '${name}' saved successfully (${jsonString.length} bytes).`);
        } catch (e) {
            console.error("[RRUNebStore] Failed to write cookie:", e);
        }
    };

    window.getCookie = function(name) {
        const nameEQ = name + "=";
        const ca = document.cookie.split(';');
        for(let i = 0; i < ca.length; i++) {
            let c = ca[i];
            while (c.charAt(0) === ' ') c = c.substring(1, c.length);
            if (c.indexOf(nameEQ) === 0) {
                try {
                    return JSON.parse(decodeURIComponent(c.substring(nameEQ.length, c.length)));
                } catch (e) {
                    console.error("[RRUNebStore] Failed to parse cookie data:", e);
                    return null;
                }
            }
        }
        return null;
    };

    window.deleteCookie = function(name) {
        document.cookie = name + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/; SameSite=Lax;";
    };

    // --- NEB Environment & Tracker Storage Controller (`RRUNebStore`) ---
    window.RRUNebStore = {
        currentNebData: null,
        mode: 'development',

        loadNebFromFile(nebPath) {
            console.log(`[RRUNebStore] Loading publication .neb file from source: ${nebPath}`);
            return null;
        },

        init() {
            const urlParams = new URLSearchParams(window.location.search);
            const nebQuery = urlParams.get('neb');

            if (nebQuery) {
                this.mode = 'publication';
                console.log('[RRUNebStore] &neb= parameter detected. Running in PUBLICATION mode.');
                this.currentNebData = this.loadNebFromFile(nebQuery);
            } else {
                this.mode = 'development';
                const savedCookieData = window.getCookie('rru_active_neb');
                
                // Fallback check: inspect tracker state if direct neb cookie is missing/empty
                let payload = savedCookieData;
                if (!payload || !payload.nodes || payload.nodes.length === 0) {
                    const trackerFallback = window.getCookie('rru_tracker_state');
                    if (trackerFallback) payload = trackerFallback;
                }

                if (payload) {
                    // Normalize whether payload is an array or full tracker wrapper object
                    const nodesArray = Array.isArray(payload) ? payload : (payload.nodes || payload.atoms || []);
                    
                    if (nodesArray.length > 0) {
                        this.currentNebData = payload;
                        console.log(`[RRUNebStore] Loaded ${nodesArray.length} items from persistent store.`);
                        
                        nodesArray.forEach(item => {
                            const pos = new THREE.Vector3(
                                item.position?.x || 0, 
                                item.position?.y || 0, 
                                item.position?.z || 0
                            );
                            const hue = item.hue !== undefined ? item.hue : 185;
                            const innerHue = item.innerHue !== undefined ? item.innerHue : ((hue + 45) % 360);
                            const scale = item.scale !== undefined ? item.scale : 1.0;
                            const cardType = item.cardType || item.type || 'stargate';
                            const cardData = item.cardData || {};
                            const id = item.id || ++window.RRURouter.nextNodeId;

                            if (id >= window.RRURouter.nextNodeId) {
                                window.RRURouter.nextNodeId = id + 1;
                            }

                            const newNode = window.createRRUNode(cardType, pos, id, hue, scale, cardData, innerHue);
                            if (newNode) {
                                window.atoms.push(newNode);
                                if (window.RRUMap && typeof window.RRUMap.addEntity === 'function') {
                                    window.RRUMap.addEntity(newNode);
                                }
                            }
                        });

                        setTimeout(() => {
                            window.atoms.forEach(node => window.attachRedXToNodeCard(node));
                            if (typeof window.updateTrackerUI === 'function') window.updateTrackerUI();
                            if (typeof window.rebuildConnections === 'function') window.rebuildConnections();
                        }, 100);
                    }
                }
            }
        },

        compileAndSave() {
            if (this.mode === 'publication') return;

            // 1. Build node compilation array
            const serializedNodes = window.atoms.map(a => ({
                id: a.id,
                hue: a.hue !== undefined ? a.hue : 185,
                innerHue: a.innerHue !== undefined ? a.innerHue : ((a.hue !== undefined ? a.hue : 185) + 45) % 360,
                scale: a.scaleMultiplier || a.scale?.x || 1.0,
                cardType: a.cardType || a.type || 'stargate',
                position: { 
                    x: Math.round(a.position?.x || 0), 
                    y: Math.round(a.position?.y || 0), 
                    z: Math.round(a.position?.z || 0) 
                },
                cardData: a.cardData || {}
            }));

            // 2. Build full tracker state snapshot
            const trackerSnapshot = {
                version: "2.0",
                timestamp: Date.now(),
                activeType: window.RRURouter?.selectedType || 'stargate',
                nextNodeId: window.RRURouter?.nextNodeId || 1,
                count: serializedNodes.length,
                nodes: serializedNodes
            };

            this.currentNebData = trackerSnapshot;

            // 3. Persist BOTH primary neb cookie and tracker state cookie
            window.setCookie('rru_active_neb', serializedNodes, 30);
            window.setCookie('rru_tracker_state', trackerSnapshot, 30);

            console.log(`[RRUNebStore] Tracker state snapshot compiled & saved (${serializedNodes.length} nodes).`);
        }
    };

    // --- Clipboard & Export/Import Controls ---
    window.exportNetworkToClipboard = function() {
        if (!window.atoms || window.atoms.length === 0) {
            alert("No nodes in network to export.");
            return;
        }
        window.RRUNebStore.compileAndSave();
        const jsonString = JSON.stringify(window.RRUNebStore.currentNebData, null, 2);

        navigator.clipboard.writeText(jsonString).then(() => {
            window.showClipboardNotification("Tracker state & constellation copied to clipboard!");
        }).catch(err => {
            console.error("Failed to copy network data: ", err);
            prompt("Copy constellation JSON manually:", jsonString);
        });
    };

    window.importNetworkFromClipboard = function() {
        navigator.clipboard.readText().then(text => {
            try {
                const parsed = JSON.parse(text);
                // Support direct arrays or wrapper objects containing a .nodes array
                const importedData = Array.isArray(parsed) ? parsed : (parsed.nodes || parsed.atoms);
                if (!Array.isArray(importedData)) throw new Error("Invalid format");

                window.clearAllNodes(true);

                importedData.forEach(item => {
                    const pos = new THREE.Vector3(
                        item.position?.x || 0, 
                        item.position?.y || 0, 
                        item.position?.z || 0
                    );
                    const hue = item.hue !== undefined ? item.hue : 185;
                    const innerHue = item.innerHue !== undefined ? item.innerHue : ((hue + 45) % 360);
                    const scale = item.scale !== undefined ? item.scale : 1.0;
                    const cardType = item.cardType || item.type || 'stargate';
                    const cardData = item.cardData || {};
                    const id = item.id || ++window.RRURouter.nextNodeId;

                    if (id >= window.RRURouter.nextNodeId) {
                        window.RRURouter.nextNodeId = id + 1;
                    }

                    const newNode = window.createRRUNode(cardType, pos, id, hue, scale, cardData, innerHue);

                    if (newNode) {
                        window.atoms.push(newNode);
                        if (window.RRUMap && typeof window.RRUMap.addEntity === 'function') {
                            window.RRUMap.addEntity(newNode);
                        }
                    }
                });

                window.RRUNebStore.compileAndSave();
                window.atoms.forEach(node => window.attachRedXToNodeCard(node));
                if (typeof window.updateTrackerUI === 'function') window.updateTrackerUI();
                if (typeof window.rebuildConnections === 'function') window.rebuildConnections();
                window.showClipboardNotification(`Successfully imported tracker state (${importedData.length} nodes)!`);
            } catch (e) {
                alert("Clipboard data is not a valid RRU tracker state or constellation JSON.");
            }
        }).catch(err => {
            console.error("Failed to read clipboard: ", err);
        });
    };

    window.showClipboardNotification = function(message) {
        let notify = document.getElementById('clipNotification');
        if (!notify) {
            notify = document.createElement('div');
            notify.id = 'clipNotification';
            notify.className = 'fixed top-20 right-6 z-50 glass-panel px-4 py-2.5 rounded-xl border border-cyan-400 text-cyan-300 text-xs font-mono shadow-[0_0_20px_rgba(0,242,255,0.4)] transition-all opacity-0 translate-y-[-10px]';
            document.body.appendChild(notify);
        }
        notify.textContent = message;
        notify.style.opacity = '1';
        notify.style.transform = 'translateY(0)';

        setTimeout(() => {
            notify.style.opacity = '0';
            notify.style.transform = 'translateY(-10px)';
        }, 2500);
    };

    // --- Main Router Object ---
    const RRURouter = {
        selectedType: 'stargate',
        dropperActive: false,
        nextNodeId: 1,

        init() {
            window.RRUNebStore.init();

            const selectEl = document.getElementById('node-type-select');
            const toggleBtn = document.getElementById('toggle-deploy-btn');
            const clearBtn = document.getElementById('clear-all-btn');
            const statusBar = document.getElementById('status-bar');
            const container = document.getElementById('webgl-container');

            if (selectEl) {
                selectEl.addEventListener('change', (e) => {
                    this.selectedType = e.target.value;
                    if (this.dropperActive && statusBar) {
                        statusBar.textContent = `STATUS: DEPLOYING [${this.selectedType.toUpperCase()}]`;
                    }
                });
            }

            if (toggleBtn) {
                toggleBtn.addEventListener('click', () => {
                    this.dropperActive = !this.dropperActive;
                    if (this.dropperActive) {
                        toggleBtn.style.background = 'rgba(0, 242, 255, 0.3)';
                        toggleBtn.style.boxShadow = '0 0 15px rgba(0, 242, 255, 0.5)';
                        toggleBtn.textContent = 'Dropper ACTIVE (Click Map)';
                        if (statusBar) statusBar.textContent = `STATUS: DEPLOYING [${this.selectedType.toUpperCase()}]`;
                    } else {
                        toggleBtn.style.background = 'rgba(0, 242, 255, 0.05)';
                        toggleBtn.style.boxShadow = 'none';
                        toggleBtn.textContent = 'Enable Dropper Mode';
                        if (statusBar) statusBar.textContent = 'STATUS: ONLINE // MAP READY';
                    }
                });
            }

            if (clearBtn) {
                clearBtn.addEventListener('click', () => {
                    window.clearAllNodes();
                });
            }

            if (container) {
                container.addEventListener('click', (e) => {
                    if (!this.dropperActive) return;
                    if (!window.RRUMap) return;

                    const worldPos = window.RRUMap.get3DPosition(e.clientX, e.clientY);
                    this.deployNode(this.selectedType, worldPos);
                });
            }

            const hueSlider = document.getElementById('node-hue') || document.getElementById('hue-slider');
            const innerHueSlider = document.getElementById('node-inner-hue') || document.getElementById('inner-hue-slider');
            const scaleSlider = document.getElementById('node-scale') || document.getElementById('scale-slider');

            if (hueSlider) {
                hueSlider.addEventListener('input', (e) => {
                    const val = Number(e.target.value);
                    if (selectedNodeForInspection) {
                        selectedNodeForInspection.hue = val;
                        if (typeof selectedNodeForInspection.setHue === 'function') selectedNodeForInspection.setHue(val);
                        else if (typeof selectedNodeForInspection.updateHue === 'function') selectedNodeForInspection.updateHue(val);
                        window.RRUNebStore.compileAndSave();
                    }
                });
            }

            if (innerHueSlider) {
                innerHueSlider.addEventListener('input', (e) => {
                    const val = Number(e.target.value);
                    if (selectedNodeForInspection) {
                        selectedNodeForInspection.innerHue = val;
                        if (typeof selectedNodeForInspection.setInnerHue === 'function') selectedNodeForInspection.setInnerHue(val);
                        else if (typeof selectedNodeForInspection.updateInnerHue === 'function') selectedNodeForInspection.updateInnerHue(val);
                        window.RRUNebStore.compileAndSave();
                    }
                });
            }

            if (scaleSlider) {
                scaleSlider.addEventListener('input', (e) => {
                    const val = Number(e.target.value);
                    if (selectedNodeForInspection) {
                        selectedNodeForInspection.scaleMultiplier = val;
                        if (typeof selectedNodeForInspection.setScale === 'function') selectedNodeForInspection.setScale(val);
                        window.RRUNebStore.compileAndSave();
                    }
                });
            }

            const designerPanel = document.getElementById('rru-designer-panel');
            const closeBtn = document.getElementById('designer-close-btn');
            const saveCookieBtn = document.getElementById('designer-save-cookie-btn');
            const copyJsonBtn = document.getElementById('designer-copy-btn');

            if (closeBtn && designerPanel) {
                closeBtn.addEventListener('click', () => {
                    designerPanel.style.display = 'none';
                    selectedNodeForInspection = null;
                });
            }
            if (saveCookieBtn) {
                saveCookieBtn.addEventListener('click', () => {
                    window.RRUNebStore.compileAndSave();
                    window.showClipboardNotification("Tracker state & cookies saved!");
                });
            }
            if (copyJsonBtn) copyJsonBtn.addEventListener('click', window.exportNetworkToClipboard);

            // --- Robust Global Event Delegation for Red X Deletion ---
            document.addEventListener('click', (ev) => {
                const redXBtn = ev.target.closest('.card-red-x-btn');
                if (!redXBtn) return;

                ev.stopPropagation();
                
                const nodeId = redXBtn.dataset.nodeId || redXBtn.getAttribute('data-node-id');
                let targetNode = null;

                if (nodeId) {
                    targetNode = window.atoms.find(a => String(a.id) === String(nodeId));
                }

                if (!targetNode) {
                    const cardEl = redXBtn.closest('[id^="node-card-"]');
                    if (cardEl) {
                        const extractedId = cardEl.id.replace('node-card-', '');
                        targetNode = window.atoms.find(a => String(a.id) === String(extractedId));
                    }
                }

                if (targetNode) {
                    window.deleteNode(targetNode);
                } else {
                    console.warn("[RRURouter] Red X clicked, but associated node could not be resolved.");
                }
            });
        },

        deployNode(type, position) {
            const id = this.nextNodeId++;
            const hue = getUIHue();
            const innerHue = getUIInnerHue();
            const scale = getUIScale();
            const cardData = {};

            const newNode = window.createRRUNode(type, position, id, hue, scale, cardData, innerHue);

            if (newNode) {
                window.atoms.push(newNode);

                if (window.RRUMap && typeof window.RRUMap.addEntity === 'function') {
                    window.RRUMap.addEntity(newNode);
                }

                window.RRUNebStore.compileAndSave();

                setTimeout(() => {
                    if (typeof window.updateTrackerUI === 'function') {
                        window.updateTrackerUI();
                    }
                    window.attachRedXToNodeCard(newNode);
                }, 50);
            }
        },

        inspectNode(node) {
            selectedNodeForInspection = node;
            const hueSlider = document.getElementById('node-hue') || document.getElementById('hue-slider');
            const innerHueSlider = document.getElementById('node-inner-hue') || document.getElementById('inner-hue-slider');
            const scaleSlider = document.getElementById('node-scale') || document.getElementById('scale-slider');
            
            if (hueSlider && node.hue !== undefined) hueSlider.value = node.hue;
            if (innerHueSlider && node.innerHue !== undefined) innerHueSlider.value = node.innerHue;
            if (scaleSlider && node.scaleMultiplier !== undefined) scaleSlider.value = node.scaleMultiplier;
        }
    };

    RRURouter.init();
    window.RRURouter = RRURouter;
})();

// --- 3D Card Red X Integration & Node Deletion ---
window.attachRedXToNodeCard = function(node) {
    let cardElement = node.cardElement || document.getElementById(`node-card-${node.id}`) || node.element;
    
    if (cardElement && !cardElement.querySelector('.card-red-x-btn')) {
        const redXBtn = document.createElement('button');
        redXBtn.className = 'card-red-x-btn';
        redXBtn.innerHTML = '&times;';
        redXBtn.title = 'Delete Node from Map';
        
        redXBtn.dataset.nodeId = node.id;

        redXBtn.style.cssText = `
            position: absolute;
            top: 6px;
            right: 6px;
            width: 22px;
            height: 22px;
            background: rgba(255, 68, 68, 0.2);
            border: 1px solid rgba(255, 68, 68, 0.6);
            color: #ff4444;
            font-weight: bold;
            font-size: 14px;
            line-height: 18px;
            text-align: center;
            border-radius: 4px;
            cursor: pointer;
            z-index: 1000;
            transition: all 0.2s ease;
        `;

        redXBtn.addEventListener('mouseover', () => {
            redXBtn.style.background = 'rgba(255, 68, 68, 0.5)';
            redXBtn.style.color = '#ffffff';
        });
        redXBtn.addEventListener('mouseout', () => {
            redXBtn.style.background = 'rgba(255, 68, 68, 0.2)';
            redXBtn.style.color = '#ff4444';
        });

        if (window.getComputedStyle(cardElement).position === 'static') {
            cardElement.style.position = 'relative';
        }
        cardElement.appendChild(redXBtn);
    }
};

window.deleteNode = function(nodeOrIndex, skipUIUpdate = false) {
    let index = -1;
    let node = null;

    if (typeof nodeOrIndex === 'number') {
        index = nodeOrIndex;
        node = window.atoms ? window.atoms[index] : null;
    } else {
        node = nodeOrIndex;
        index = window.atoms ? window.atoms.indexOf(node) : -1;
    }

    if (!node && index !== -1 && window.atoms) {
        node = window.atoms[index];
    }

    if (node) {
        if (typeof node.dispose === 'function') {
            try { node.dispose(); } catch(e) { console.warn("Dispose error:", e); }
        }
        
        const targetMesh = node.group || node.mesh || (node.isObject3D ? node : null);
        
        if (targetMesh && typeof targetMesh.traverse === 'function') {
            targetMesh.traverse(child => {
                if (child.geometry) child.geometry.dispose();
                if (child.material) {
                    if (Array.isArray(child.material)) {
                        child.material.forEach(mat => {
                            if (mat.map) mat.map.dispose();
                            mat.dispose();
                        });
                    } else {
                        if (child.material.map) child.material.map.dispose();
                        child.material.dispose();
                    }
                }
            });
            if (targetMesh.parent) {
                targetMesh.parent.remove(targetMesh);
            }
        }

        const cardElement = node.cardElement || document.getElementById(`node-card-${node.id}`);
        if (cardElement) cardElement.remove();

        if (window.RRUMap && typeof window.RRUMap.removeEntity === 'function') {
            window.RRUMap.removeEntity(node);
        }

        if (index !== -1 && window.atoms[index] === node) {
            window.atoms.splice(index, 1);
        } else {
            const foundIdx = window.atoms.indexOf(node);
            if (foundIdx !== -1) {
                window.atoms.splice(foundIdx, 1);
            }
        }

        if (window.RRUNebStore && typeof window.RRUNebStore.compileAndSave === 'function') {
            window.RRUNebStore.compileAndSave();
        }

        if (!skipUIUpdate) {
            if (typeof window.rebuildConnections === 'function') window.rebuildConnections();
            if (typeof window.updateTrackerUI === 'function') window.updateTrackerUI();
        }
    }
};

window.deleteNodeAtIndex = function(index, skipUIUpdate = false) {
    window.deleteNode(index, skipUIUpdate);
};

window.clearAllNodes = function(skipCookieSave = false) {
    if (window.atoms && window.atoms.length > 0) {
        while (window.atoms.length > 0) {
            window.deleteNode(window.atoms[window.atoms.length - 1], true);
        }
    }

    if (window.RRUMap && typeof window.RRUMap.clearAllEntities === 'function') {
        window.RRUMap.clearAllEntities();
    }

    if (!skipCookieSave && window.RRUNebStore && typeof window.RRUNebStore.compileAndSave === 'function') {
        window.RRUNebStore.compileAndSave();
    }

    if (typeof window.rebuildConnections === 'function') {
        window.rebuildConnections();
    }
    if (typeof window.updateTrackerUI === 'function') {
        window.updateTrackerUI();
    }
    window.showClipboardNotification("Tracker state cleared and cookies reset.");
};